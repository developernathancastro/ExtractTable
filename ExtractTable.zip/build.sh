#!/bin/bash

zip -r "ExtractTable.zip" * -x "ExtractTable.zip"